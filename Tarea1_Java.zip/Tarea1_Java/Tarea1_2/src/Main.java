public class Main {
    public static void main(String[] args) {
        coche micoche = new coche();
        micoche.IncrementarPuerta();
        System.out.println(micoche.puertas);
    }

    }

class coche {
    public int puertas = 0;

    public void IncrementarPuerta() {
        this.puertas--;
    }
}