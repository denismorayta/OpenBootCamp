public class Main {


    public static void main(String[] args) {
        int resultado;
        resultado = suma(10,20,30);
        System.out.println(resultado);
    }

    private static int suma(int a, int b, int c) {
        return a + b + c;
    }
}
